"""Group E points predictor: main page.

Run from the repo root:
    python src/train_final.py      # creates app/data/
    streamlit run app/app.py

Layout follows reports/site_wireframe.png, top to bottom:
    header -> inputs -> prediction card + last 10 games -> why + opponent ranks -> footer
Shared colors and CSS live in app/ui.py so every page looks the same.
"""
import json
from pathlib import Path

import altair as alt
import numpy as np
import pandas as pd
import streamlit as st
import xgboost as xgb

from ui import (BLUE, BLUE_DARK, BLUE_LIGHT, GRID, INK_2, PAST_GRAY, RED, esc, footer, html, ordinal,
                setup_page, team_name)

DATA = Path(__file__).resolve().parent / "data"

# Model features grouped into plain-English reasons for the "why" section.
# Add new features to a group here; anything not listed shows up as "Other factors".
REASONS = {
    "Recent scoring": ["pts_l5", "pts_l10", "pts_szn", "fga_l10", "fta_l10", "fg3a_l10"],
    "Minutes and role": ["min_l5", "min_l10", "starter_rate_l10", "games_played_szn"],
    "Usage and shooting": ["usg_l5", "usg_l10", "usg_szn", "ts_l10"],
    "Opponent defense": ["opp_drtg_l10"],          # plus every opp_pts_allowed_* feature
    "Game pace": ["opp_pace_l10", "team_pace_l10"],
    "Home or away": ["home"],
    "Rest": ["rest_days", "b2b"],
    "Teammates out": ["tm_out_min", "tm_out_usg", "tm_out_count"],
}


def reason_for(feature):
    if feature.startswith("opp_pts_allowed"):
        return "Opponent defense"
    return next((name for name, feats in REASONS.items() if feature in feats), "Other factors")


# ---------------------------------------------------------------- data + model

@st.cache_resource
def load():
    meta = json.loads((DATA / "meta.json").read_text())
    booster = xgb.Booster()
    booster.load_model(DATA / "model.json")
    players = pd.read_csv(DATA / "player_state.csv")
    teams = pd.read_csv(DATA / "team_state.csv")
    teams["def_rank"] = teams.drtg_l10.rank(method="min").astype(int)                    # 1 = best defense
    teams["pace_rank"] = teams.pace_l10.rank(ascending=False, method="min").astype(int)  # 1 = fastest
    return meta, booster, players, teams


@st.cache_data
def load_recent():
    """Each player's last 10 games (app/data/recent_games.csv, written by train_final.py).
    Returns None until that file exists."""
    path = DATA / "recent_games.csv"
    if not path.exists():
        return None
    df = pd.read_csv(path).rename(columns={"game_date": "date", "opp": "opponent", "pts": "points",
                                           "min": "minutes"})
    df["date"] = pd.to_datetime(df["date"])
    return df


def placeholder_games(p, teams, n=10):
    """Made-up games in the same columns as recent_games.csv, so the chart works before the real
    file exists. Averages out to the player's real last-10 scoring."""
    rng = np.random.default_rng(int(p.player_id))
    pts = rng.normal(0, max(2.0, 0.3 * p.pts_l10), n)
    pts = np.clip(np.round(pts - pts.mean() + p.pts_l10), 0, None)
    opps = rng.choice(teams.team[teams.team != p.team].to_numpy(), n, replace=False)
    last = pd.Timestamp(p.last_game)
    return pd.DataFrame({
        "date": [last - pd.Timedelta(days=2 * i) for i in reversed(range(n))],
        "opponent": opps, "home": rng.integers(0, 2, n), "points": pts,
        "minutes": np.clip(np.round(rng.normal(p.min_l10, 3, n), 1), 0, 48),
    })


def player_games(recent, p, teams):
    """(last 10 games, is_placeholder) for player p."""
    if recent is not None:
        key = "player_id" if "player_id" in recent.columns else "player"
        g = recent[recent[key] == p[key]].sort_values("date").tail(10)
        if len(g):
            return g, False
    return placeholder_games(p, teams), True


def predict(meta, booster, row):
    X = pd.DataFrame([row]).reindex(columns=meta["features"])   # new features -> NaN, still runs
    dm = xgb.DMatrix(X)
    pred = float(booster.predict(dm)[0])
    contribs = booster.predict(dm, pred_contribs=True)[0]
    drivers = pd.Series(contribs[:-1], index=meta["features"])   # last value is the starting point
    r = next((r for r in meta["ranges"] if r["lo"] <= pred < r["hi"]), meta["ranges"][-1])
    return pred, max(0, pred + r["q10"]), pred + r["q90"], drivers, float(contribs[-1])


def num(v, spec=".1f", fallback="–"):
    return fallback if pd.isna(v) else format(v, spec)


# ---------------------------------------------------------------- page pieces

def prediction_card(p, opp, home, rest, n_out, pred, lo, hi):
    top = max(30, int(np.ceil(hi / 10) * 10))          # right end of the range bar
    pos = lambda v: f"{100 * min(max(v, 0), top) / top:.1f}%"
    where = f"vs {opp} · Home" if home else f"@ {opp} · Away"
    rest_txt = "back-to-back" if rest == 1 else f"{rest} days rest"
    out_txt = f" · {n_out} teammate{'s' if n_out > 1 else ''} out" if n_out else ""
    html(f"""
    <div class="kicker">Predicted points</div>
    <div class="pred-who">{esc(p.player)}</div>
    <div class="pred-ctx">{esc(p.team)} {where} · {rest_txt}{out_txt}</div>
    <div class="pred-big">{pred:.1f}<span>pts</span></div>
    <div class="range-track">
      <div class="range-band" style="left:{pos(lo)}; width:calc({pos(hi)} - {pos(lo)});"></div>
      <div class="range-mark" style="left:{pos(pred)};"></div>
    </div>
    <div class="range-ends"><span>0</span><span>{top}</span></div>
    <div class="range-text">Likely range: <b>{lo:.0f}–{hi:.0f} pts</b></div>
    <div class="muted">About 8 in 10 games land in this range.</div>
    <div class="stat-row">
      <div><div class="stat-label">Last 10 avg</div><div class="stat-value">{num(p.pts_l10)}</div></div>
      <div><div class="stat-label">Season avg</div><div class="stat-value">{num(p.pts_szn)}</div></div>
      <div><div class="stat-label">Usage, last 5</div><div class="stat-value">{num(p.usg_l5, '.0f')}%</div></div>
    </div>""")


def last10_chart(games, opp, home, pred, lo, hi):
    g = games.copy()
    has_home = "home" in g.columns

    def opp_label(r):
        o = str(r.opponent)
        if has_home and not o.startswith("@"):
            o = ("" if r.home else "@") + o
        return o

    g["opp_label"] = [opp_label(r) for r in g.itertuples()]
    g["x"] = [f"{o}|{d.month}/{d.day}" for o, d in zip(g.opp_label, g.date)]
    nxt = pd.DataFrame({"x": [f"{'' if home else '@'}{opp}|Next"], "points": [round(pred, 1)],
                        "lo": [round(lo, 1)], "hi": [round(hi, 1)]})
    avg = pd.DataFrame({"avg": [g.points.mean()], "label": [f"avg {g.points.mean():.1f}"]})

    x = alt.X("x:N", sort=list(g.x) + list(nxt.x), title=None,
              scale=alt.Scale(paddingInner=0.38, paddingOuter=0.2),
              axis=alt.Axis(labelExpr="split(datum.label, '|')", labelAngle=0, ticks=False,
                            domainColor=GRID, labelColor=INK_2, labelFontSize=10.5, labelPadding=6))
    y_top = float(max(g.points.max(), hi)) * 1.12
    y = alt.Y("points:Q", title=None, scale=alt.Scale(domain=[0, y_top], nice=True),
              axis=alt.Axis(gridColor=GRID, domain=False, ticks=False, tickCount=5, labelColor=INK_2))

    past = alt.Chart(g).mark_bar(color=PAST_GRAY, cornerRadiusTopLeft=4, cornerRadiusTopRight=4).encode(
        x=x, y=y, tooltip=[alt.Tooltip("date:T", title="Date", format="%b %d, %Y"),
                           alt.Tooltip("opp_label:N", title="Opponent"),
                           alt.Tooltip("points:Q", title="Points"),
                           alt.Tooltip("minutes:Q", title="Minutes", format=".1f")])
    tip = [alt.Tooltip("points:Q", title="Predicted", format=".1f"),
           alt.Tooltip("lo:Q", title="Range low", format=".0f"),
           alt.Tooltip("hi:Q", title="Range high", format=".0f")]
    base = alt.Chart(nxt).encode(x=x)
    next_bar = base.mark_bar(color=BLUE_LIGHT, stroke=BLUE, strokeDash=[4, 3], strokeWidth=1.5,
                             cornerRadiusTopLeft=4, cornerRadiusTopRight=4).encode(y=y, tooltip=tip)
    whisker = base.mark_rule(color=BLUE, strokeWidth=2).encode(y="lo:Q", y2="hi:Q", tooltip=tip)
    caps = (base.mark_tick(color=BLUE, thickness=2, size=12).encode(y="lo:Q")
            + base.mark_tick(color=BLUE, thickness=2, size=12).encode(y="hi:Q"))
    value = base.mark_text(dy=-9, color=BLUE_DARK, fontWeight="bold", fontSize=12).encode(
        y="hi:Q", text=alt.Text("points:Q", format=".1f"))
    avg_line = alt.Chart(avg).mark_rule(color=INK_2, strokeDash=[5, 4], strokeWidth=1.5).encode(y="avg:Q")
    avg_text = alt.Chart(avg).mark_text(align="left", dx=2, dy=-7, color=INK_2, fontSize=11).encode(
        x=alt.value(0), y="avg:Q", text="label:N")

    chart = alt.layer(past, next_bar, whisker, caps, value, avg_line, avg_text).properties(height=270)
    return chart.configure_view(strokeWidth=0)


def why_section(drivers, start, pred, context):
    groups = drivers.groupby(drivers.index.map(reason_for)).sum()
    groups = groups.reindex(groups.abs().sort_values(ascending=False).index)
    scale = max(float(groups.abs().max()), 1e-9)
    rows = []
    for name, v in groups.items():
        width = 50 * abs(v) / scale
        if abs(v) < 0.05:
            icon, bar = f'<span style="color:#c3c2b7">●</span>', ""
        elif v > 0:
            icon = f'<span style="color:{BLUE}">▲</span>'
            bar = f'<div class="fill" style="left:50%; width:{width:.1f}%; background:{BLUE}; border-radius:0 3px 3px 0"></div>'
        else:
            icon = f'<span style="color:{RED}">▼</span>'
            bar = f'<div class="fill" style="right:50%; width:{width:.1f}%; background:{RED}; border-radius:3px 0 0 3px"></div>'
        rows.append(f"""<div class="reason"><div class="icon">{icon}</div>
            <div><div class="t">{name}</div><div class="s">{esc(context.get(name, "Other model inputs"))}</div></div>
            <div class="rbar"><div class="zero"></div>{bar}</div><div class="v">{"0.0" if abs(v) < 0.05 else format(v, "+.1f")}</div></div>""")
    html(f"""
    <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:.3rem 1rem">
      <div class="kicker">Why {pred:.1f}? The main reasons</div>
      <div class="legend"><span><span style="color:{BLUE}">▲</span> pushes it up</span>
        <span><span style="color:{RED}">▼</span> pulls it down</span></div>
    </div>
    <div class="band-row band-start"><span>Starting point: a typical player's game</span><b>{start:.1f}</b></div>
    {''.join(rows)}
    <div class="band-row band-total"><span>Predicted points</span><b>{pred:.1f}</b></div>
    <div class="small" style="margin-top:.7rem">Each row is how much that part of the model moved the
      prediction. The starting point plus every row adds up to the prediction.</div>""")


def opponent_card(teams, opp):
    o = teams[teams.team == opp].iloc[0]
    d, pc = int(o.def_rank), int(o.pace_rank)
    d_word = ("one of the toughest defenses right now" if d <= 5 else "a good defense" if d <= 10
              else "about average" if d <= 20 else "a below-average defense" if d <= 25
              else "one of the easiest defenses to score on")
    p_word = ("plays fast, so more shots to go around" if pc <= 10 else "average pace" if pc <= 20
              else "plays slow, so fewer shots to go around")

    def track(rank, left, right):
        dots = "".join(f'<i class="{"on" if i == rank else ""}"></i>' for i in range(1, 31))
        return f'<div class="track30">{dots}</div><div class="track-ends"><span>{left}</span><span>{right}</span></div>'

    html(f"""
    <div class="kicker">How the {esc(team_name(opp))} compare</div>
    <div class="muted">Last 10 games, ranked against all 30 teams.</div>
    <div class="rank-head"><span class="t">Defense</span><span class="r">{ordinal(d)} <span>of 30</span></span></div>
    {track(d, "Best", "Worst")}
    <div class="muted" style="margin-top:.35rem">Allows {o.drtg_l10:.1f} points per 100 possessions
      (league avg {teams.drtg_l10.mean():.1f}): {d_word}.</div>
    <div class="rank-head"><span class="t">Pace</span><span class="r">{ordinal(pc)} <span>of 30</span></span></div>
    {track(pc, "Fastest", "Slowest")}
    <div class="muted" style="margin-top:.35rem">{o.pace_l10:.1f} possessions per game
      (league avg {teams.pace_l10.mean():.1f}): {p_word}.</div>
    <div class="small" style="margin-top:1rem">In our data, facing the best vs. the worst defense
      changed scoring by only about half a point, so this matters less than you might think.</div>""")


# ---------------------------------------------------------------- page

setup_page("NBA Points Predictor")
meta, booster, players, teams = load()

html('<div class="eyebrow">NBA Points Predictor · Eclipse Analytics, Group E</div>')
st.title("How many points will he score?", anchor=False)
html(f"""<div class="lede">Pick a player and an opponent, set the game details, and the model predicts
  his points. It only uses information you'd have before tipoff. Player and team form is as of the
  end of our data ({pd.Timestamp(meta['data_through']):%b %d, %Y}).</div>""")

# Inputs
by_scoring = players.sort_values("pts_szn", ascending=False)
team_of = dict(zip(by_scoring.player, by_scoring.team))
names = by_scoring.player.tolist()
c1, c2 = st.columns(2)
player = c1.selectbox("Player", names, index=names.index("LeBron James") if "LeBron James" in names else 0,
                      format_func=lambda n: f"{n} · {team_of[n]}",
                      help="Sorted by scoring average. Start typing to search.")
p = players[players.player == player].iloc[0]
opps = sorted(teams.team[teams.team != p.team], key=team_name)
opp = c2.selectbox("Opponent", opps, index=opps.index("BOS") if "BOS" in opps else 0,
                   format_func=lambda t: f"{team_name(t)} ({t})")

c3, c4, c5 = st.columns([1, 1, 2])
home = c3.segmented_control("Where", ["Home", "Away"], default="Home") != "Away"
rest = c4.slider("Days of rest", 1, 5, 2, help="1 = second game of a back-to-back")
mates = players[(players.team == p.team) & (players.player != player) & (players.min_l10 >= 20)]
out = c5.multiselect("Teammates sitting out", sorted(mates.player), placeholder="Nobody, full rotation",
                     help="Regular teammates (20+ minutes a game lately) who won't play.")
out_df = mates[mates.player.isin(out)]

# Prediction
own, o = teams[teams.team == p.team].iloc[0], teams[teams.team == opp].iloc[0]
row = {**p.to_dict(), "opp_drtg_l10": o.drtg_l10, "opp_pace_l10": o.pace_l10,
       "team_pace_l10": own.pace_l10, "home": int(home), "rest_days": rest, "b2b": int(rest == 1),
       "tm_out_min": out_df.min_l10.sum(), "tm_out_usg": out_df.usg_l10.sum(),
       "tm_out_count": len(out_df)}
pred, lo, hi, drivers, start = predict(meta, booster, row)
games, is_placeholder = player_games(load_recent(), p, teams)

st.write("")
left, right = st.columns([1, 1.7], gap="medium")
with left.container(border=True):
    prediction_card(p, opp, home, rest, len(out_df), pred, lo, hi)
with right.container(border=True):
    html(f"""<div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:.3rem 1rem">
      <div class="kicker">Last 10 games</div>
      <div class="legend"><span><span class="sw" style="background:{PAST_GRAY}"></span>Points</span>
        <span><span class="sw-line"></span>Last-10 avg</span>
        <span><span class="sw" style="background:{BLUE_LIGHT}; outline:1.5px dashed {BLUE}"></span>Next game (predicted)</span>
      </div></div>""")
    st.altair_chart(last10_chart(games, opp, home, pred, lo, hi))
    if is_placeholder:
        st.caption("Placeholder games for now. Real game logs appear once recent_games.csv is added.")
    else:
        st.caption("Hover over a bar for minutes and the date.")

context = {
    "Recent scoring": f"{num(p.pts_l10)} pts a game over his last 10, {num(p.pts_szn)} on the season",
    "Minutes and role": f"{num(p.min_l10)} minutes a game lately; started "
                        f"{round(p.starter_rate_l10 * min(10, p.games_played_szn))} of his last "
                        f"{int(min(10, p.games_played_szn))}",
    "Usage and shooting": f"Uses {num(p.usg_l10, '.0f')}% of his team's plays when he's on the floor "
                          f"(season: {num(p.usg_szn, '.0f')}%)",
    "Opponent defense": f"{team_name(opp)} allow {o.drtg_l10:.1f} points per 100 possessions lately "
                        f"({ordinal(o.def_rank)} best of 30)",
    "Game pace": f"{team_name(opp)}: {o.pace_l10:.1f} possessions a game ({ordinal(o.pace_rank)} fastest); "
                 f"{p.team}: {own.pace_l10:.1f}",
    "Home or away": "Playing at home" if home else "Playing on the road",
    "Rest": "Second night of a back-to-back" if rest == 1 else f"{rest} days of rest",
    "Teammates out": f"{', '.join(out)} out, so more shots to go around" if out
                     else "Full rotation available, no extra shots to pick up",
}

st.write("")
left2, right2 = st.columns([1.7, 1], gap="medium")
with left2.container(border=True):
    why_section(drivers, start, pred, context)
with right2.container(border=True):
    opponent_card(teams, opp)

footer(meta)
