"""About the data: where the numbers come from, plus the three clearest findings from our EDA.

Reads app/data/about.json (made by `python src/export_about_data.py`), so it works online
without the big data/processed/ files.
"""
import json
from pathlib import Path

import altair as alt
import pandas as pd
import streamlit as st

from ui import BLUE, GRID, INK, INK_2, MUTED, RED, footer, html, setup_page

DATA = Path(__file__).resolve().parents[1] / "data"
SPLIT_COLORS = {"Earlier seasons": "#c3c2b7", "Training": BLUE, "Tuning": "#eb6834", "Final test": "#1baf7a"}

setup_page("About the data · NBA Points Predictor")
about = json.loads((DATA / "about.json").read_text())
meta = json.loads((DATA / "meta.json").read_text())
facts = about["facts"]


def diff_chart(records, x_title):
    """Average points vs. last-10 average per group. Blue = above, red = below, whiskers = 95% CI."""
    d = pd.DataFrame(records)
    d["lo"], d["hi"] = d["mean"] - d.ci, d["mean"] + d.ci
    d["label"] = d["mean"].map(lambda v: "0.0" if abs(v) < 0.05 else f"{v:+.1f}")
    d["label_y"] = d.apply(lambda r: r.hi if r["mean"] >= 0 else r.lo, axis=1)
    d["dy"] = d["mean"].map(lambda v: -8 if v >= 0 else 10)
    x = alt.X("bin:N", sort=list(d.bin), title=x_title,
              scale=alt.Scale(paddingInner=0.45),
              axis=alt.Axis(labelAngle=0, ticks=False, domain=False, labelColor=INK_2, titleColor=INK_2,
                            titleFontWeight="normal", labelPadding=6, labelLimit=120))
    y_scale = alt.Scale(domain=[-2.8, 2.8])   # same scale on every chart so they compare honestly
    tip = [alt.Tooltip("bin:N", title="Group"), alt.Tooltip("games:Q", title="Player-games", format=","),
           alt.Tooltip("mean:Q", title="Avg vs. last-10", format="+.2f"),
           alt.Tooltip("beat:Q", title="Beat his last-10 avg", format=".0%")]
    base = alt.Chart(d).encode(x=x)
    bars = base.mark_bar(cornerRadius=3).encode(
        y=alt.Y("mean:Q", scale=y_scale, title="Points vs. his last-10 average",
                axis=alt.Axis(gridColor=GRID, domain=False, ticks=False, tickCount=7, labelColor=INK_2,
                              titleColor=INK_2, titleFontWeight="normal")),
        color=alt.condition("datum.mean >= 0", alt.value(BLUE), alt.value(RED)), tooltip=tip)
    whiskers = base.mark_rule(color=MUTED, strokeWidth=1.5).encode(y="lo:Q", y2="hi:Q", tooltip=tip)
    zero = alt.Chart(pd.DataFrame({"y": [0]})).mark_rule(color="#c3c2b7").encode(y="y:Q")
    up = base.transform_filter("datum.mean >= 0").mark_text(dy=-8, color=INK, fontSize=12).encode(
        y="label_y:Q", text="label:N")
    down = base.transform_filter("datum.mean < 0").mark_text(dy=12, color=INK, fontSize=12).encode(
        y="label_y:Q", text="label:N")
    return alt.layer(zero, bars, whiskers, up, down).properties(height=260).configure_view(strokeWidth=0)


def season_chart(seasons):
    d = pd.DataFrame(seasons)
    return alt.Chart(d).mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3).encode(
        x=alt.X("season:N", title=None, axis=alt.Axis(labelAngle=-45, labelOverlap=False, ticks=False,
                                                      domainColor=GRID, labelColor=INK_2, labelFontSize=10)),
        y=alt.Y("player_games:Q", title="Player-games",
                axis=alt.Axis(gridColor=GRID, domain=False, ticks=False, values=[0, 10000, 20000, 30000],
                              labelExpr="datum.value == 0 ? '0' : datum.value / 1000 + 'k'",
                              labelColor=INK_2, titleColor=INK_2, titleFontWeight="normal")),
        color=alt.Color("split:N", legend=None,       # legend is drawn in HTML above, so it wraps on phones
                        scale=alt.Scale(domain=list(SPLIT_COLORS), range=list(SPLIT_COLORS.values()))),
        tooltip=[alt.Tooltip("season:N", title="Season"), alt.Tooltip("split:N", title="Used for"),
                 alt.Tooltip("player_games:Q", title="Player-games", format=",")],
    ).properties(height=280).configure_view(strokeWidth=0)


def finding(title, text, records, x_title):
    with st.container(border=True):
        left, right = st.columns([1, 1.5], gap="large")
        with left:
            html(f'<div class="kicker">Finding</div><h3 style="margin-top:0">{title}</h3>'
                 f'<div class="muted" style="font-size:.95rem; line-height:1.55">{text}</div>')
        with right:
            st.altair_chart(diff_chart(records, x_title))


# ---------------------------------------------------------------- page

html('<div class="eyebrow">NBA Points Predictor · Eclipse Analytics, Group E</div>')
st.title("About the data", anchor=False)
html(f"""<div class="lede">Every NBA regular-season box score from {facts['first_season']} to
  {facts['last_season']}, one row per player per game. Before each game we only use what was known
  before tipoff, and we test the model on a season it never saw.</div>""")

tiles = [(f"{facts['player_games']:,}", "player-games"), (f"{facts['players']:,}", "players"),
         (str(len(about["seasons"])), "seasons"), (f"{meta['test_mae']:.2f} pts", "average miss on 2023-24")]
html('<div class="tiles">' + "".join(f'<div class="tile"><div class="stat-value">{v}</div>'
                                     f'<div class="stat-label">{k}</div></div>' for v, k in tiles) + "</div>")

st.write("")
with st.container(border=True):
    left, right = st.columns([1, 1.5], gap="large")
    with left:
        html("""<div class="kicker">How we test it</div><h3 style="margin-top:0">Split by season, never at random</h3>
        <div class="muted" style="font-size:.95rem; line-height:1.55">The model learns from 2015-16 to
        2021-22, we tune its settings on 2022-23, and we report its accuracy on 2023-24 only. That way
        the final number reflects games the model had never seen, the same as a real upcoming game.
        The dips are the shortened 2011-12 lockout season and the two COVID seasons.</div>""")
    with right:
        html('<div class="legend" style="margin-bottom:.3rem">' + "".join(
            f'<span><span class="sw" style="background:{c}"></span>{k}</span>' for k, c in SPLIT_COLORS.items())
            + "</div>")
        st.altair_chart(season_chart(about["seasons"]))

html(f"""<h2 style="margin-top:1.6rem">What we found</h2>
<div class="muted" style="margin:-.4rem 0 .9rem">The question behind each chart: does a player score more or
less than his own last-10 average? Training seasons only ({facts['train_player_games']:,} player-games).
Overall, players beat their last-10 average just {facts['beat_rate_overall']:.0%} of the time.</div>""")

out = {r["bin"]: r for r in about["teammates_out"]}
finding("Teammates sitting out is the clearest signal",
        f"When regular teammates who together use 40%+ of the team's plays are out (about two starters), "
        f"players beat their last-10 average {out['40%+']['beat']:.0%} of the time, by "
        f"{out['40%+']['mean']:+.1f} points on average. With nobody out it's {out['Nobody out']['beat']:.0%}.",
        about["teammates_out"], "Combined usage of regular teammates who are out")

hot = {r["bin"]: r for r in about["streak"]}
finding("Hot streaks cool off, cold streaks bounce back",
        f"When a player's last-10 average is 3+ points above his season average, he scores "
        f"{abs(hot['Hot (3+ above)']['mean']):.1f} points below that last-10 average in the next game. "
        f"Cold streaks do the opposite ({hot['Cold (3+ below)']['mean']:+.1f}). That's why the model leans "
        f"on the season average, not just recent games.",
        about["streak"], "Last-10 average compared with his season average")

dfn = {r["bin"]: r for r in about["defense"]}
finding("Opponent defense barely matters",
        f"Against the best fifth of defenses, players score {abs(dfn['Best']['mean']):.1f} points below "
        f"their last-10 average. Against the worst fifth, {abs(dfn['Worst']['mean']):.1f} above. That "
        f"half-point swing is small next to the model's typical miss of about 4.5 points.",
        about["defense"], "Opponent's defense over its last 10 games (fifths)")

html(f"""<div class="small" style="margin-top:.6rem">Whiskers show 95% confidence intervals. Hover over a bar
for the number of games. Source: NBA.com box scores via the NocturneBear/NBA-Data-2010-2024 dataset (MIT
license).</div>""")
footer(meta)
