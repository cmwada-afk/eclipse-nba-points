"""Shared look for every page of the site: colors, CSS, and small helpers.

Any page can do:
    from ui import setup_page, html
    setup_page("Page title")
"""
from html import escape

import streamlit as st

# Colors (same palette as the EDA notebook)
BLUE, BLUE_LIGHT, BLUE_DARK = "#2a78d6", "#cde2fb", "#184f95"
RED = "#e34948"
INK, INK_2, MUTED = "#0b0b0b", "#52514e", "#898781"
GRID, PAST_GRAY = "#e1e0d9", "#aeaca3"

TEAM_NAMES = {
    "ATL": "Atlanta Hawks", "BOS": "Boston Celtics", "BKN": "Brooklyn Nets", "CHA": "Charlotte Hornets",
    "CHI": "Chicago Bulls", "CLE": "Cleveland Cavaliers", "DAL": "Dallas Mavericks", "DEN": "Denver Nuggets",
    "DET": "Detroit Pistons", "GSW": "Golden State Warriors", "HOU": "Houston Rockets",
    "IND": "Indiana Pacers", "LAC": "LA Clippers", "LAL": "Los Angeles Lakers", "MEM": "Memphis Grizzlies",
    "MIA": "Miami Heat", "MIL": "Milwaukee Bucks", "MIN": "Minnesota Timberwolves",
    "NOP": "New Orleans Pelicans", "NYK": "New York Knicks", "OKC": "Oklahoma City Thunder",
    "ORL": "Orlando Magic", "PHI": "Philadelphia 76ers", "PHX": "Phoenix Suns",
    "POR": "Portland Trail Blazers", "SAC": "Sacramento Kings", "SAS": "San Antonio Spurs",
    "TOR": "Toronto Raptors", "UTA": "Utah Jazz", "WAS": "Washington Wizards",
}

CSS = f"""
<style>
.block-container {{max-width: 1140px; padding-top: 2.4rem; padding-bottom: 2rem;}}
h1 {{letter-spacing: -0.02em;}}
.eyebrow {{font-size: .78rem; font-weight: 700; letter-spacing: .06em; text-transform: uppercase;
  color: {INK_2}; margin-bottom: -.4rem;}}
.lede {{color: {INK_2}; font-size: 1.02rem; line-height: 1.55; margin-top: -.5rem; padding-bottom: .9rem; max-width: 46rem;}}
.kicker {{font-size: .74rem; font-weight: 700; letter-spacing: .07em; text-transform: uppercase;
  color: {INK_2}; margin: 0 0 .6rem;}}
.muted {{color: {INK_2}; font-size: .85rem;}}
.small {{font-size: .78rem; line-height: 1.45; color: {MUTED};}}

/* prediction card */
.pred-who {{font-weight: 650; font-size: 1.1rem; line-height: 1.3;}}
.pred-ctx {{color: {INK_2}; font-size: .86rem;}}
.pred-big {{font-size: 4.4rem; font-weight: 750; color: {BLUE}; line-height: 1; margin: 1rem 0 .1rem;
  letter-spacing: -0.03em;}}
.pred-big span {{font-size: 1.3rem; color: {INK_2}; font-weight: 500; margin-left: .35rem; letter-spacing: 0;}}
.range-track {{position: relative; height: 10px; background: #f0efec; border-radius: 5px; margin: 1.1rem 0 .3rem;}}
.range-band {{position: absolute; top: 0; bottom: 0; background: {BLUE_LIGHT}; border: 1px solid #6da7ec;
  border-radius: 5px;}}
.range-mark {{position: absolute; top: -5px; width: 3px; height: 20px; background: {BLUE}; border-radius: 2px;
  transform: translateX(-50%); box-shadow: 0 0 0 2px #fff;}}
.range-ends {{display: flex; justify-content: space-between; font-size: .74rem; color: {MUTED};}}
.range-text {{font-size: .95rem; margin-top: .5rem;}}
.stat-row {{display: flex; gap: 1rem; border-top: 1px solid {GRID}; margin-top: 1.1rem; padding-top: .8rem;}}
.stat-row > div {{flex: 1;}}
.stat-label {{font-size: .76rem; color: {INK_2};}}
.stat-value {{font-size: 1.35rem; font-weight: 700;}}

/* legends */
.legend {{display: flex; flex-wrap: wrap; gap: .3rem 1rem; font-size: .78rem; color: {INK_2};}}
.sw {{display: inline-block; width: 10px; height: 10px; border-radius: 2px; margin-right: .35rem;
  vertical-align: -1px;}}
.sw-line {{display: inline-block; width: 16px; border-top: 2px dashed {INK_2}; margin-right: .35rem;
  vertical-align: 3px;}}

/* "why" list */
.reason {{display: grid; grid-template-columns: 1.1rem 1fr minmax(64px, 28%) 3.4rem; align-items: center;
  gap: .75rem; padding: .7rem .2rem; border-bottom: 1px solid #eeede8;}}
.reason .icon {{font-size: .8rem; text-align: center;}}
.reason .t {{font-weight: 600; font-size: .95rem; line-height: 1.25;}}
.reason .s {{color: {INK_2}; font-size: .82rem; line-height: 1.3; margin-top: .1rem;}}
.reason .v {{text-align: right; font-weight: 700; font-variant-numeric: tabular-nums;}}
.rbar {{position: relative; height: 12px;}}
.rbar .zero {{position: absolute; left: 50%; top: -5px; bottom: -5px; width: 1px; background: #c3c2b7;}}
.rbar .fill {{position: absolute; top: 0; height: 100%;}}
.band-row {{display: flex; justify-content: space-between; align-items: center; gap: 1rem;
  border-radius: 8px; padding: .65rem .9rem; font-size: .95rem;}}
.band-row b {{font-variant-numeric: tabular-nums;}}
.band-start {{background: #f5f4f0; margin-bottom: .2rem;}}
.band-total {{background: #e6f0fc; margin-top: .7rem; color: {BLUE_DARK};}}

/* opponent ranks */
.rank-head {{display: flex; justify-content: space-between; align-items: baseline; gap: .5rem; margin-top: .9rem;}}
.rank-head .t {{font-weight: 600;}}
.rank-head .r {{font-weight: 750; font-size: 1.25rem; white-space: nowrap;}}
.rank-head .r span {{font-size: .8rem; font-weight: 500; color: {INK_2};}}
.track30 {{display: flex; justify-content: space-between; align-items: center; height: 18px; margin: .45rem 0 .15rem;}}
.track30 i {{display: block; width: 6px; height: 6px; border-radius: 50%; background: #d6d5ce;}}
.track30 i.on {{width: 14px; height: 14px; background: {BLUE}; box-shadow: 0 0 0 2px #fff;}}
.track-ends {{display: flex; justify-content: space-between; font-size: .72rem; color: {MUTED};}}

/* stat tiles (wrap into 2x2 on phones) */
.tiles {{display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: .8rem; margin-bottom: .6rem;}}
.tile {{border: 1px solid #dddcd5; border-radius: .5rem; padding: .8rem 1rem;}}
.tile .stat-value {{font-size: 1.6rem;}}

/* footer */
.foot {{display: flex; flex-wrap: wrap; justify-content: space-between; gap: .4rem 1.5rem;
  font-size: .78rem; color: {MUTED}; border-top: 1px solid {GRID}; margin-top: 2.2rem; padding-top: 1rem;}}

@media (max-width: 640px) {{
  .block-container {{padding-top: 1.2rem;}}
  .pred-big {{font-size: 3.4rem;}}
  .reason {{grid-template-columns: .9rem 1fr 56px 3rem; gap: .5rem;}}
  .stat-value {{font-size: 1.15rem;}}
}}
</style>
"""


def setup_page(title):
    """Call once at the top of every page (before any other st.* call)."""
    st.set_page_config(page_title=title, page_icon="🏀", layout="wide")
    st.markdown(CSS, unsafe_allow_html=True)


def html(s):
    """Render an HTML snippet. Newlines are collapsed so Markdown doesn't turn indents into code."""
    st.markdown(" ".join(line.strip() for line in s.splitlines()), unsafe_allow_html=True)


def esc(s):
    return escape(str(s))


def team_name(abbr):
    return TEAM_NAMES.get(abbr, abbr)


def ordinal(n):
    n = int(n)
    suffix = "th" if 10 <= n % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
    return f"{n}{suffix}"


def footer(meta):
    html(f"""
    <div class="foot">
      <div>Uses only pre-game info · XGBoost, average miss {meta['test_mae']:.2f} pts on the
      {meta['test_season']} season · Data: NBA.com box scores through {meta['data_through']}</div>
      <div>Not betting advice · Eclipse Analytics, Group E</div>
    </div>""")
