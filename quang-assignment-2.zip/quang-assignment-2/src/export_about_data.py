"""Export the numbers behind the "About the data" page into app/data/about.json.

The website can't read data/processed/ (it isn't committed), so this script
boils the EDA charts from notebooks/01_eda_starter.ipynb down to a few small
tables the site can load. Same definitions as the notebook: training seasons
only, and "diff" = points scored minus his last-10 average.

Usage:  python src/export_about_data.py      (after build_features.py)
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PROC, APP = ROOT / "data" / "processed", ROOT / "app" / "data"
TRAIN = ["2015-16", "2016-17", "2017-18", "2018-19", "2019-20", "2020-21", "2021-22"]
SPLITS = {"Training": TRAIN, "Tuning": ["2022-23"], "Final test": ["2023-24"]}


def diff_table(df, bins):
    """Average (pts - pts_l10) per bin, with a 95% confidence interval and beat rate."""
    g = df.groupby(bins, observed=True).agg(games=("diff", "size"), mean=("diff", "mean"),
                                            std=("diff", "std"), beat=("beat", "mean"))
    g["ci"] = 1.96 * g["std"] / np.sqrt(g["games"])
    g = g.reset_index().rename(columns={bins.name: "bin"})
    g["bin"] = g["bin"].astype(str)
    return g[["bin", "games", "mean", "ci", "beat"]].round(3).to_dict("records")


def main():
    model = pd.read_csv(PROC / "model_table.csv", usecols=["season", "player_id", "pts", "pts_l10",
                                                            "pts_szn", "opp_drtg_l10", "tm_out_usg"])
    train = model[model.season.isin(TRAIN)].copy()
    train["diff"] = train.pts - train.pts_l10
    train["beat"] = (train.pts > train.pts_l10).astype(int)

    out = pd.cut(train.tm_out_usg, [-0.1, 0, 20, 40, 1000],
                 labels=["Nobody out", "Under 20%", "20-40%", "40%+"])   # a typical starter uses ~20% of plays
    out.name = "teammates_out"

    gap = train.pts_l10 - train.pts_szn
    streak = pd.cut(gap, [-np.inf, -3, -1, 1, 3, np.inf],
                    labels=["Cold (3+ below)", "A bit cold", "Normal", "A bit hot", "Hot (3+ above)"])
    streak.name = "streak"

    defense = pd.qcut(train.opp_drtg_l10, 5, labels=["Best", "Good", "Average", "Weak", "Worst"])
    defense.name = "defense"

    seasons = (model.groupby("season").size().rename("player_games").reset_index())
    seasons["split"] = seasons.season.map({s: k for k, v in SPLITS.items() for s in v}).fillna("Earlier seasons")

    about = {
        "facts": {
            "player_games": int(len(model)),
            "players": int(model.player_id.nunique()),
            "first_season": model.season.min(), "last_season": model.season.max(),
            "train_player_games": int(len(train)),
            "beat_rate_overall": round(float(train.beat.mean()), 3),
        },
        "seasons": seasons.to_dict("records"),
        "teammates_out": diff_table(train, out),
        "streak": diff_table(train, streak),
        "defense": diff_table(train, defense),
    }
    APP.mkdir(parents=True, exist_ok=True)
    (APP / "about.json").write_text(json.dumps(about, indent=1))
    print("wrote", APP / "about.json")


if __name__ == "__main__":
    main()
